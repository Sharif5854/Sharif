function Click(event) {
    event.preventDefault();

    var username = document.getElementById("name").value;
    var password = document.getElementById("password").value;
    var gender = document.getElementsByName("gender");
    var education;
    var hobbies = document.getElementsByName("hobbies");
    var comment = document.getElementById("comment").value;
    

    for(i=0;i<gender.length;i++) {
        if(gender[i].checked===true){
            var genderValue = gender[i].value;
        }
    }

    for(i=0;i<hobbies.length;i++) {
        if(hobbies[i].checked===true){
            var hobbiesResult = hobbies[i].value;
        }
    }

    var education = document.getElementById("eduaction");
    var value = education.value;
    var text = education.options[education.selectedIndex].text;

    

    document.getElementById("nameResult").innerHTML=username;
    document.getElementById("passwordResult").innerHTML=password;
    document.getElementById("genderResult").innerHTML=genderValue;
    document.getElementById("educationResult").innerHTML=text;
    document.getElementById("hobbyResult").innerHTML=hobbiesResult;
    document.getElementById("commentResult").innerHTML=comment;
}